"""Another entrypoint for python module script, e.g. running `python -m darts`."""

from darts.cli import start_app

start_app()
